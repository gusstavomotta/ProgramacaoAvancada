public enum EnumLivro {

    DIDATICO, INFANTIL, FICCAO, AUTO_AJUDA
}
