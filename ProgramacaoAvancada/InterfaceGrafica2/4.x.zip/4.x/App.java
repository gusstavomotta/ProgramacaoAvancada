public class App {
    
    public static void main (String args[]) {

        CaixaGrande caixa = new CaixaGrande();
        
    }
}
